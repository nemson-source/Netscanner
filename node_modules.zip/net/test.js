
var i = require("./index.js")

console.log(Socket instanceof Function)


