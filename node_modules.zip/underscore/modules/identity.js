// Keep the identity function around for default iteratees.
export default function identity(value) {
  return value;
}
