define(['./_shallowProperty'], function (_shallowProperty) {

	// Internal helper to obtain the `byteLength` property of an object.
	var getByteLength = _shallowProperty('byteLength');

	return getByteLength;

});
